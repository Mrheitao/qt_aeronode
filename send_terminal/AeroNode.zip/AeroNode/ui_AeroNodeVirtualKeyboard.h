/********************************************************************************
** Form generated from reading ui file 'WidgetKeyboard.ui'
**
********************************************************************************/

#ifndef UI_WIDGETKEYBOARD_H
#define UI_WIDGETKEYBOARD_H
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QFrame>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QSlider>
#include <QtGui/QSpacerItem>
#include <QtGui/QToolButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
QT_BEGIN_NAMESPACE

class Ui_WidgetKeyboard
{
public:
    QVBoxLayout *verticalLayout_2;
    QGridLayout *gridLayout_5;
    QHBoxLayout *horizontalLayout_9;
    QToolButton *btnPrint;
    QToolButton *btnHome_2;
    QToolButton *btnPgU_2;
    QGridLayout *gridLayout_3;
    QHBoxLayout *horizontalLayout;
    QToolButton *btnTilt;
    QToolButton *btn1;
    QToolButton *btn2;
    QToolButton *btn3;
    QToolButton *btn4;
    QToolButton *btn5;
    QToolButton *btn6;
    QToolButton *btn7;
    QToolButton *btn8;
    QToolButton *btn9;
    QToolButton *btn0;
    QToolButton *btnHiphen;
    QToolButton *btnAssign;
    QToolButton *btnBackSpace;
    QHBoxLayout *horizontalLayout_3;
    QToolButton *btnCaps;
    QToolButton *btnA;
    QToolButton *btnS;
    QToolButton *btnD;
    QToolButton *btnF;
    QToolButton *btnG;
    QToolButton *btnH;
    QToolButton *btnJ;
    QToolButton *btnK;
    QToolButton *btnL;
    QToolButton *btnSemiColon;
    QToolButton *btnSp;
    QToolButton *btnReturn;
    QHBoxLayout *horizontalLayout_4;
    QToolButton *btnShiftLeft;
    QToolButton *btnZ;
    QToolButton *btnX;
    QToolButton *btnC;
    QToolButton *btnV;
    QToolButton *btnB;
    QToolButton *btnN;
    QToolButton *btnM;
    QToolButton *btnComma;
    QToolButton *btnPeriod;
    QToolButton *btnBcwdSlash;
    QToolButton *btnShiftRight;
    QHBoxLayout *horizontalLayout_5;
    QToolButton *btnCtrlLeft;
    QToolButton *btnAltLeft;
    QToolButton *btnSpace;
    QSlider *sliderOpacity;
    QHBoxLayout *horizontalLayout_2;
    QToolButton *btnTab;
    QToolButton *btnQ;
    QToolButton *btnW;
    QToolButton *btnE;
    QToolButton *btnR;
    QToolButton *btnT;
    QToolButton *btnY;
    QToolButton *btnU;
    QToolButton *btnI;
    QToolButton *btnO;
    QToolButton *btnP;
    QToolButton *btnStartSquare;
    QToolButton *btnCloseSquare;
    QToolButton *btnFwdSlash;
	
    void setupUi(QWidget *WidgetKeyboard)
    {
		if (WidgetKeyboard->objectName().isEmpty())
            WidgetKeyboard->setObjectName(QString::fromUtf8("WidgetKeyboard"));
        //WidgetKeyboard->resize(240, 60);		
        verticalLayout_2 = new QVBoxLayout(WidgetKeyboard);
        verticalLayout_2->setSpacing(1);
        verticalLayout_2->setMargin(1);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        gridLayout_5 = new QGridLayout();
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        
		horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(1);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        QFont font;
        font.setPointSize(12);
 

        //ƽ������
        gridLayout_3 = new QGridLayout();
        gridLayout_3->setSpacing(2);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(1);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        btnTilt = new QToolButton(WidgetKeyboard);
        btnTilt->setObjectName(QString::fromUtf8("btnTilt"));
        sizePolicy.setHeightForWidth(btnTilt->sizePolicy().hasHeightForWidth());
        btnTilt->setSizePolicy(sizePolicy);
        btnTilt->setFont(font);
        btnTilt->setAutoRepeat(true);

        horizontalLayout->addWidget(btnTilt);

        btn1 = new QToolButton(WidgetKeyboard);
        btn1->setObjectName(QString::fromUtf8("btn1"));
        sizePolicy.setHeightForWidth(btn1->sizePolicy().hasHeightForWidth());
        btn1->setSizePolicy(sizePolicy);
        btn1->setFont(font);
        btn1->setAutoRepeat(true);

        horizontalLayout->addWidget(btn1);

        btn2 = new QToolButton(WidgetKeyboard);
        btn2->setObjectName(QString::fromUtf8("btn2"));
        sizePolicy.setHeightForWidth(btn2->sizePolicy().hasHeightForWidth());
        btn2->setSizePolicy(sizePolicy);
        btn2->setFont(font);
        btn2->setAutoRepeat(true);

        horizontalLayout->addWidget(btn2);

        btn3 = new QToolButton(WidgetKeyboard);
        btn3->setObjectName(QString::fromUtf8("btn3"));
        sizePolicy.setHeightForWidth(btn3->sizePolicy().hasHeightForWidth());
        btn3->setSizePolicy(sizePolicy);
        btn3->setFont(font);
        btn3->setAutoRepeat(true);

        horizontalLayout->addWidget(btn3);

        btn4 = new QToolButton(WidgetKeyboard);
        btn4->setObjectName(QString::fromUtf8("btn4"));
        sizePolicy.setHeightForWidth(btn4->sizePolicy().hasHeightForWidth());
        btn4->setSizePolicy(sizePolicy);
        btn4->setFont(font);
        btn4->setAutoRepeat(true);

        horizontalLayout->addWidget(btn4);

        btn5 = new QToolButton(WidgetKeyboard);
        btn5->setObjectName(QString::fromUtf8("btn5"));
        sizePolicy.setHeightForWidth(btn5->sizePolicy().hasHeightForWidth());
        btn5->setSizePolicy(sizePolicy);
        btn5->setFont(font);
        btn5->setAutoRepeat(true);

        horizontalLayout->addWidget(btn5);

        btn6 = new QToolButton(WidgetKeyboard);
        btn6->setObjectName(QString::fromUtf8("btn6"));
        sizePolicy.setHeightForWidth(btn6->sizePolicy().hasHeightForWidth());
        btn6->setSizePolicy(sizePolicy);
        btn6->setFont(font);
        btn6->setAutoRepeat(true);

        horizontalLayout->addWidget(btn6);

        btn7 = new QToolButton(WidgetKeyboard);
        btn7->setObjectName(QString::fromUtf8("btn7"));
        sizePolicy.setHeightForWidth(btn7->sizePolicy().hasHeightForWidth());
        btn7->setSizePolicy(sizePolicy);
        btn7->setFont(font);
        btn7->setAutoRepeat(true);

        horizontalLayout->addWidget(btn7);

        btn8 = new QToolButton(WidgetKeyboard);
        btn8->setObjectName(QString::fromUtf8("btn8"));
        sizePolicy.setHeightForWidth(btn8->sizePolicy().hasHeightForWidth());
        btn8->setSizePolicy(sizePolicy);
        btn8->setFont(font);
        btn8->setAutoRepeat(true);

        horizontalLayout->addWidget(btn8);

        btn9 = new QToolButton(WidgetKeyboard);
        btn9->setObjectName(QString::fromUtf8("btn9"));
        sizePolicy.setHeightForWidth(btn9->sizePolicy().hasHeightForWidth());
        btn9->setSizePolicy(sizePolicy);
        btn9->setFont(font);
        btn9->setAutoRepeat(true);

        horizontalLayout->addWidget(btn9);

        btn0 = new QToolButton(WidgetKeyboard);
        btn0->setObjectName(QString::fromUtf8("btn0"));
        sizePolicy.setHeightForWidth(btn0->sizePolicy().hasHeightForWidth());
        btn0->setSizePolicy(sizePolicy);
        btn0->setFont(font);
        btn0->setAutoRepeat(true);

        horizontalLayout->addWidget(btn0);

        btnHiphen = new QToolButton(WidgetKeyboard);
        btnHiphen->setObjectName(QString::fromUtf8("btnHiphen"));
        sizePolicy.setHeightForWidth(btnHiphen->sizePolicy().hasHeightForWidth());
        btnHiphen->setSizePolicy(sizePolicy);
        btnHiphen->setFont(font);
        btnHiphen->setAutoRepeat(true);

        horizontalLayout->addWidget(btnHiphen);

        btnAssign = new QToolButton(WidgetKeyboard);
        btnAssign->setObjectName(QString::fromUtf8("btnAssign"));
        sizePolicy.setHeightForWidth(btnAssign->sizePolicy().hasHeightForWidth());
        btnAssign->setSizePolicy(sizePolicy);
        btnAssign->setFont(font);
        btnAssign->setAutoRepeat(true);

        horizontalLayout->addWidget(btnAssign);

        btnBackSpace = new QToolButton(WidgetKeyboard);
        btnBackSpace->setObjectName(QString::fromUtf8("btnBackSpace"));
        sizePolicy.setHeightForWidth(btnBackSpace->sizePolicy().hasHeightForWidth());
        btnBackSpace->setSizePolicy(sizePolicy);
        btnBackSpace->setFont(font);
        btnBackSpace->setAutoRepeat(true);

        horizontalLayout->addWidget(btnBackSpace);


        gridLayout_3->addLayout(horizontalLayout, 0, 0, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(1);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        btnCaps = new QToolButton(WidgetKeyboard);
        btnCaps->setObjectName(QString::fromUtf8("btnCaps"));
        sizePolicy.setHeightForWidth(btnCaps->sizePolicy().hasHeightForWidth());
        btnCaps->setSizePolicy(sizePolicy);
        btnCaps->setFont(font);
        btnCaps->setCheckable(true);
        btnCaps->setAutoRepeat(true);

        horizontalLayout_3->addWidget(btnCaps);

        btnA = new QToolButton(WidgetKeyboard);
        btnA->setObjectName(QString::fromUtf8("btnA"));
        sizePolicy.setHeightForWidth(btnA->sizePolicy().hasHeightForWidth());
        btnA->setSizePolicy(sizePolicy);
        btnA->setFont(font);
        btnA->setAutoRepeat(true);

        horizontalLayout_3->addWidget(btnA);

        btnS = new QToolButton(WidgetKeyboard);
        btnS->setObjectName(QString::fromUtf8("btnS"));
        sizePolicy.setHeightForWidth(btnS->sizePolicy().hasHeightForWidth());
        btnS->setSizePolicy(sizePolicy);
        btnS->setFont(font);
        btnS->setAutoRepeat(true);

        horizontalLayout_3->addWidget(btnS);

        btnD = new QToolButton(WidgetKeyboard);
        btnD->setObjectName(QString::fromUtf8("btnD"));
        sizePolicy.setHeightForWidth(btnD->sizePolicy().hasHeightForWidth());
        btnD->setSizePolicy(sizePolicy);
        btnD->setFont(font);
        btnD->setAutoRepeat(true);

        horizontalLayout_3->addWidget(btnD);

        btnF = new QToolButton(WidgetKeyboard);
        btnF->setObjectName(QString::fromUtf8("btnF"));
        sizePolicy.setHeightForWidth(btnF->sizePolicy().hasHeightForWidth());
        btnF->setSizePolicy(sizePolicy);
        btnF->setFont(font);
        btnF->setAutoRepeat(true);

        horizontalLayout_3->addWidget(btnF);

        btnG = new QToolButton(WidgetKeyboard);
        btnG->setObjectName(QString::fromUtf8("btnG"));
        sizePolicy.setHeightForWidth(btnG->sizePolicy().hasHeightForWidth());
        btnG->setSizePolicy(sizePolicy);
        btnG->setFont(font);
        btnG->setAutoRepeat(true);

        horizontalLayout_3->addWidget(btnG);

        btnH = new QToolButton(WidgetKeyboard);
        btnH->setObjectName(QString::fromUtf8("btnH"));
        sizePolicy.setHeightForWidth(btnH->sizePolicy().hasHeightForWidth());
        btnH->setSizePolicy(sizePolicy);
        btnH->setFont(font);
        btnH->setAutoRepeat(true);

        horizontalLayout_3->addWidget(btnH);

        btnJ = new QToolButton(WidgetKeyboard);
        btnJ->setObjectName(QString::fromUtf8("btnJ"));
        sizePolicy.setHeightForWidth(btnJ->sizePolicy().hasHeightForWidth());
        btnJ->setSizePolicy(sizePolicy);
        btnJ->setFont(font);
        btnJ->setAutoRepeat(true);

        horizontalLayout_3->addWidget(btnJ);

        btnK = new QToolButton(WidgetKeyboard);
        btnK->setObjectName(QString::fromUtf8("btnK"));
        sizePolicy.setHeightForWidth(btnK->sizePolicy().hasHeightForWidth());
        btnK->setSizePolicy(sizePolicy);
        btnK->setFont(font);
        btnK->setAutoRepeat(true);

        horizontalLayout_3->addWidget(btnK);

        btnL = new QToolButton(WidgetKeyboard);
        btnL->setObjectName(QString::fromUtf8("btnL"));
        sizePolicy.setHeightForWidth(btnL->sizePolicy().hasHeightForWidth());
        btnL->setSizePolicy(sizePolicy);
        btnL->setFont(font);
        btnL->setAutoRepeat(true);

        horizontalLayout_3->addWidget(btnL);

        btnSemiColon = new QToolButton(WidgetKeyboard);
        btnSemiColon->setObjectName(QString::fromUtf8("btnSemiColon"));
        sizePolicy.setHeightForWidth(btnSemiColon->sizePolicy().hasHeightForWidth());
        btnSemiColon->setSizePolicy(sizePolicy);
        btnSemiColon->setFont(font);
        btnSemiColon->setAutoRepeat(true);

        horizontalLayout_3->addWidget(btnSemiColon);

        btnSp = new QToolButton(WidgetKeyboard);
        btnSp->setObjectName(QString::fromUtf8("btnSp"));
        sizePolicy.setHeightForWidth(btnSp->sizePolicy().hasHeightForWidth());
        btnSp->setSizePolicy(sizePolicy);
        btnSp->setFont(font);
        btnSp->setAutoRepeat(true);

        horizontalLayout_3->addWidget(btnSp);

        btnReturn = new QToolButton(WidgetKeyboard);
        btnReturn->setObjectName(QString::fromUtf8("btnReturn"));
        sizePolicy.setHeightForWidth(btnReturn->sizePolicy().hasHeightForWidth());
        btnReturn->setSizePolicy(sizePolicy);
        btnReturn->setFont(font);
        btnReturn->setAutoRepeat(true);

        horizontalLayout_3->addWidget(btnReturn);


        gridLayout_3->addLayout(horizontalLayout_3, 2, 0, 1, 1);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(1);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        btnShiftLeft = new QToolButton(WidgetKeyboard);
        btnShiftLeft->setObjectName(QString::fromUtf8("btnShiftLeft"));
        sizePolicy.setHeightForWidth(btnShiftLeft->sizePolicy().hasHeightForWidth());
        btnShiftLeft->setSizePolicy(sizePolicy);
        btnShiftLeft->setFont(font);
        btnShiftLeft->setCheckable(true);
        btnShiftLeft->setAutoRepeat(true);

        horizontalLayout_4->addWidget(btnShiftLeft);

        btnZ = new QToolButton(WidgetKeyboard);
        btnZ->setObjectName(QString::fromUtf8("btnZ"));
        sizePolicy.setHeightForWidth(btnZ->sizePolicy().hasHeightForWidth());
        btnZ->setSizePolicy(sizePolicy);
        btnZ->setFont(font);
        btnZ->setAutoRepeat(true);

        horizontalLayout_4->addWidget(btnZ);

        btnX = new QToolButton(WidgetKeyboard);
        btnX->setObjectName(QString::fromUtf8("btnX"));
        sizePolicy.setHeightForWidth(btnX->sizePolicy().hasHeightForWidth());
        btnX->setSizePolicy(sizePolicy);
        btnX->setFont(font);
        btnX->setAutoRepeat(true);

        horizontalLayout_4->addWidget(btnX);

        btnC = new QToolButton(WidgetKeyboard);
        btnC->setObjectName(QString::fromUtf8("btnC"));
        sizePolicy.setHeightForWidth(btnC->sizePolicy().hasHeightForWidth());
        btnC->setSizePolicy(sizePolicy);
        btnC->setFont(font);
        btnC->setAutoRepeat(true);

        horizontalLayout_4->addWidget(btnC);

        btnV = new QToolButton(WidgetKeyboard);
        btnV->setObjectName(QString::fromUtf8("btnV"));
        sizePolicy.setHeightForWidth(btnV->sizePolicy().hasHeightForWidth());
        btnV->setSizePolicy(sizePolicy);
        btnV->setFont(font);
        btnV->setAutoRepeat(true);

        horizontalLayout_4->addWidget(btnV);

        btnB = new QToolButton(WidgetKeyboard);
        btnB->setObjectName(QString::fromUtf8("btnB"));
        sizePolicy.setHeightForWidth(btnB->sizePolicy().hasHeightForWidth());
        btnB->setSizePolicy(sizePolicy);
        btnB->setFont(font);
        btnB->setAutoRepeat(true);

        horizontalLayout_4->addWidget(btnB);

        btnN = new QToolButton(WidgetKeyboard);
        btnN->setObjectName(QString::fromUtf8("btnN"));
        sizePolicy.setHeightForWidth(btnN->sizePolicy().hasHeightForWidth());
        btnN->setSizePolicy(sizePolicy);
        btnN->setFont(font);
        btnN->setAutoRepeat(true);

        horizontalLayout_4->addWidget(btnN);

        btnM = new QToolButton(WidgetKeyboard);
        btnM->setObjectName(QString::fromUtf8("btnM"));
        sizePolicy.setHeightForWidth(btnM->sizePolicy().hasHeightForWidth());
        btnM->setSizePolicy(sizePolicy);
        btnM->setFont(font);
        btnM->setAutoRepeat(true);

        horizontalLayout_4->addWidget(btnM);

        btnComma = new QToolButton(WidgetKeyboard);
        btnComma->setObjectName(QString::fromUtf8("btnComma"));
        sizePolicy.setHeightForWidth(btnComma->sizePolicy().hasHeightForWidth());
        btnComma->setSizePolicy(sizePolicy);
        btnComma->setFont(font);
        btnComma->setAutoRepeat(true);

        horizontalLayout_4->addWidget(btnComma);

        btnPeriod = new QToolButton(WidgetKeyboard);
        btnPeriod->setObjectName(QString::fromUtf8("btnPeriod"));
        sizePolicy.setHeightForWidth(btnPeriod->sizePolicy().hasHeightForWidth());
        btnPeriod->setSizePolicy(sizePolicy);
        btnPeriod->setFont(font);
        btnPeriod->setAutoRepeat(true);

        horizontalLayout_4->addWidget(btnPeriod);

        btnBcwdSlash = new QToolButton(WidgetKeyboard);
        btnBcwdSlash->setObjectName(QString::fromUtf8("btnBcwdSlash"));
        sizePolicy.setHeightForWidth(btnBcwdSlash->sizePolicy().hasHeightForWidth());
        btnBcwdSlash->setSizePolicy(sizePolicy);
        btnBcwdSlash->setFont(font);
        btnBcwdSlash->setAutoRepeat(true);

        horizontalLayout_4->addWidget(btnBcwdSlash);

        btnShiftRight = new QToolButton(WidgetKeyboard);
        btnShiftRight->setObjectName(QString::fromUtf8("btnShiftRight"));
        sizePolicy.setHeightForWidth(btnShiftRight->sizePolicy().hasHeightForWidth());
        btnShiftRight->setSizePolicy(sizePolicy);
        btnShiftRight->setFont(font);
        btnShiftRight->setCheckable(true);
        btnShiftRight->setAutoRepeat(true);

        horizontalLayout_4->addWidget(btnShiftRight);


        gridLayout_3->addLayout(horizontalLayout_4, 3, 0, 1, 1);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(1);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        btnCtrlLeft = new QToolButton(WidgetKeyboard);
        btnCtrlLeft->setObjectName(QString::fromUtf8("btnCtrlLeft"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(btnCtrlLeft->sizePolicy().hasHeightForWidth());
        btnCtrlLeft->setSizePolicy(sizePolicy1);
        btnCtrlLeft->setFont(font);
        btnCtrlLeft->setCheckable(true);
        btnCtrlLeft->setAutoRepeat(true);

        horizontalLayout_5->addWidget(btnCtrlLeft);

        btnAltLeft = new QToolButton(WidgetKeyboard);
        btnAltLeft->setObjectName(QString::fromUtf8("btnAltLeft"));
        sizePolicy1.setHeightForWidth(btnAltLeft->sizePolicy().hasHeightForWidth());
        btnAltLeft->setSizePolicy(sizePolicy1);
        btnAltLeft->setFont(font);
        btnAltLeft->setCheckable(true);
        btnAltLeft->setAutoRepeat(true);

        horizontalLayout_5->addWidget(btnAltLeft);

        btnSpace = new QToolButton(WidgetKeyboard);
        btnSpace->setObjectName(QString::fromUtf8("btnSpace"));
        QSizePolicy sizePolicy2(QSizePolicy::MinimumExpanding, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(btnSpace->sizePolicy().hasHeightForWidth());
        btnSpace->setSizePolicy(sizePolicy2);
        btnSpace->setFont(font);
        btnSpace->setAutoRepeat(true);

        horizontalLayout_5->addWidget(btnSpace);

        sliderOpacity = new QSlider(WidgetKeyboard);
        sliderOpacity->setObjectName(QString::fromUtf8("sliderOpacity"));
        QSizePolicy sizePolicy3(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(sliderOpacity->sizePolicy().hasHeightForWidth());
        sliderOpacity->setSizePolicy(sizePolicy3);
        sliderOpacity->setOrientation(Qt::Horizontal);

        horizontalLayout_5->addWidget(sliderOpacity);


        gridLayout_3->addLayout(horizontalLayout_5, 4, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(1);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        btnTab = new QToolButton(WidgetKeyboard);
        btnTab->setObjectName(QString::fromUtf8("btnTab"));
        sizePolicy.setHeightForWidth(btnTab->sizePolicy().hasHeightForWidth());
        btnTab->setSizePolicy(sizePolicy);
        btnTab->setFont(font);
        btnTab->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnTab);

        btnQ = new QToolButton(WidgetKeyboard);
        btnQ->setObjectName(QString::fromUtf8("btnQ"));
        sizePolicy.setHeightForWidth(btnQ->sizePolicy().hasHeightForWidth());
        btnQ->setSizePolicy(sizePolicy);
        btnQ->setFont(font);
        btnQ->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnQ);

        btnW = new QToolButton(WidgetKeyboard);
        btnW->setObjectName(QString::fromUtf8("btnW"));
        sizePolicy.setHeightForWidth(btnW->sizePolicy().hasHeightForWidth());
        btnW->setSizePolicy(sizePolicy);
        btnW->setFont(font);
        btnW->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnW);

        btnE = new QToolButton(WidgetKeyboard);
        btnE->setObjectName(QString::fromUtf8("btnE"));
        sizePolicy.setHeightForWidth(btnE->sizePolicy().hasHeightForWidth());
        btnE->setSizePolicy(sizePolicy);
        btnE->setFont(font);
        btnE->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnE);

        btnR = new QToolButton(WidgetKeyboard);
        btnR->setObjectName(QString::fromUtf8("btnR"));
        sizePolicy.setHeightForWidth(btnR->sizePolicy().hasHeightForWidth());
        btnR->setSizePolicy(sizePolicy);
        btnR->setFont(font);
        btnR->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnR);

        btnT = new QToolButton(WidgetKeyboard);
        btnT->setObjectName(QString::fromUtf8("btnT"));
        sizePolicy.setHeightForWidth(btnT->sizePolicy().hasHeightForWidth());
        btnT->setSizePolicy(sizePolicy);
        btnT->setFont(font);
        btnT->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnT);

        btnY = new QToolButton(WidgetKeyboard);
        btnY->setObjectName(QString::fromUtf8("btnY"));
        sizePolicy.setHeightForWidth(btnY->sizePolicy().hasHeightForWidth());
        btnY->setSizePolicy(sizePolicy);
        btnY->setFont(font);
        btnY->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnY);

        btnU = new QToolButton(WidgetKeyboard);
        btnU->setObjectName(QString::fromUtf8("btnU"));
        sizePolicy.setHeightForWidth(btnU->sizePolicy().hasHeightForWidth());
        btnU->setSizePolicy(sizePolicy);
        btnU->setFont(font);
        btnU->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnU);

        btnI = new QToolButton(WidgetKeyboard);
        btnI->setObjectName(QString::fromUtf8("btnI"));
        sizePolicy.setHeightForWidth(btnI->sizePolicy().hasHeightForWidth());
        btnI->setSizePolicy(sizePolicy);
        btnI->setFont(font);
        btnI->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnI);

        btnO = new QToolButton(WidgetKeyboard);
        btnO->setObjectName(QString::fromUtf8("btnO"));
        sizePolicy.setHeightForWidth(btnO->sizePolicy().hasHeightForWidth());
        btnO->setSizePolicy(sizePolicy);
        btnO->setFont(font);
        btnO->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnO);

        btnP = new QToolButton(WidgetKeyboard);
        btnP->setObjectName(QString::fromUtf8("btnP"));
        sizePolicy.setHeightForWidth(btnP->sizePolicy().hasHeightForWidth());
        btnP->setSizePolicy(sizePolicy);
        btnP->setFont(font);
        btnP->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnP);

        btnStartSquare = new QToolButton(WidgetKeyboard);
        btnStartSquare->setObjectName(QString::fromUtf8("btnStartSquare"));
        sizePolicy.setHeightForWidth(btnStartSquare->sizePolicy().hasHeightForWidth());
        btnStartSquare->setSizePolicy(sizePolicy);
        btnStartSquare->setFont(font);
        btnStartSquare->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnStartSquare);

        btnCloseSquare = new QToolButton(WidgetKeyboard);
        btnCloseSquare->setObjectName(QString::fromUtf8("btnCloseSquare"));
        sizePolicy.setHeightForWidth(btnCloseSquare->sizePolicy().hasHeightForWidth());
        btnCloseSquare->setSizePolicy(sizePolicy);
        btnCloseSquare->setFont(font);
        btnCloseSquare->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnCloseSquare);

        btnFwdSlash = new QToolButton(WidgetKeyboard);
        btnFwdSlash->setObjectName(QString::fromUtf8("btnFwdSlash"));
        sizePolicy.setHeightForWidth(btnFwdSlash->sizePolicy().hasHeightForWidth());
        btnFwdSlash->setSizePolicy(sizePolicy);
        btnFwdSlash->setFont(font);
        btnFwdSlash->setAutoRepeat(true);

        horizontalLayout_2->addWidget(btnFwdSlash);


        gridLayout_3->addLayout(horizontalLayout_2, 1, 0, 1, 1);

//gridLayout_3�Ǵ����
        gridLayout_5->addLayout(gridLayout_3, 1, 0, 1, 1);
        gridLayout_5->setRowStretch(0, 2);
        gridLayout_5->setRowStretch(1, 9);
        gridLayout_5->setColumnStretch(0, 7);
        gridLayout_5->setColumnStretch(1, 2);
        gridLayout_5->setColumnStretch(2, 2);

        verticalLayout_2->addLayout(gridLayout_5);


        retranslateUi(WidgetKeyboard);

        QMetaObject::connectSlotsByName(WidgetKeyboard);
    } // setupUi

    void retranslateUi(QWidget *WidgetKeyboard)
    {
        WidgetKeyboard->setWindowTitle(QApplication::translate("WidgetKeyboard", "Virtual Keyboard", 0, QApplication::UnicodeUTF8));


#ifndef QT_NO_ACCESSIBILITY
        btnTilt->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x60", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnTilt->setText(QApplication::translate("WidgetKeyboard", "`", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btn1->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x31", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btn1->setText(QApplication::translate("WidgetKeyboard", "1", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btn2->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x32", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btn2->setText(QApplication::translate("WidgetKeyboard", "2", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btn3->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x33", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btn3->setText(QApplication::translate("WidgetKeyboard", "3", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btn4->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x34", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btn4->setText(QApplication::translate("WidgetKeyboard", "4", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btn5->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x35", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btn5->setText(QApplication::translate("WidgetKeyboard", "5", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btn6->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x36", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btn6->setText(QApplication::translate("WidgetKeyboard", "6", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btn7->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x37", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btn7->setText(QApplication::translate("WidgetKeyboard", "7", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btn8->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x38", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btn8->setText(QApplication::translate("WidgetKeyboard", "8", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btn9->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x39", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btn9->setText(QApplication::translate("WidgetKeyboard", "9", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btn0->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x30", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btn0->setText(QApplication::translate("WidgetKeyboard", "0", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnHiphen->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x2d", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnHiphen->setText(QApplication::translate("WidgetKeyboard", "-", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnAssign->setAccessibleName(QApplication::translate("WidgetKeyboard", "13", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnAssign->setText(QApplication::translate("WidgetKeyboard", "=", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnBackSpace->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x01000003", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnBackSpace->setText(QApplication::translate("WidgetKeyboard", "Backspace", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnCaps->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x01000024", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnCaps->setText(QApplication::translate("WidgetKeyboard", "    Caps   ", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnA->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x41", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnA->setText(QApplication::translate("WidgetKeyboard", "A", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnS->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x53", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnS->setText(QApplication::translate("WidgetKeyboard", "S", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnD->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x44", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnD->setText(QApplication::translate("WidgetKeyboard", "D", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnF->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x46", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnF->setText(QApplication::translate("WidgetKeyboard", "F", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnG->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x47", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnG->setText(QApplication::translate("WidgetKeyboard", "G", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnH->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x48", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnH->setText(QApplication::translate("WidgetKeyboard", "H", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnJ->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x4a", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnJ->setText(QApplication::translate("WidgetKeyboard", "J", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnK->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x4b", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnK->setText(QApplication::translate("WidgetKeyboard", "K", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnL->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x4c", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnL->setText(QApplication::translate("WidgetKeyboard", "L", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnSemiColon->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x3b", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnSemiColon->setText(QApplication::translate("WidgetKeyboard", ";", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnSp->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x27", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnSp->setText(QApplication::translate("WidgetKeyboard", "'", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnReturn->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x01000004", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnReturn->setText(QApplication::translate("WidgetKeyboard", "    Return   ", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnShiftLeft->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x01000020", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnShiftLeft->setText(QApplication::translate("WidgetKeyboard", "     Shift     ", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnZ->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x5a", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnZ->setText(QApplication::translate("WidgetKeyboard", "Z", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnX->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x58", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnX->setText(QApplication::translate("WidgetKeyboard", "X", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnC->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x43", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnC->setText(QApplication::translate("WidgetKeyboard", "C", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnV->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x56", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnV->setText(QApplication::translate("WidgetKeyboard", "V", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnB->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x42", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnB->setText(QApplication::translate("WidgetKeyboard", "B", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnN->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x4e", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnN->setText(QApplication::translate("WidgetKeyboard", "N", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnM->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x4d", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnM->setText(QApplication::translate("WidgetKeyboard", "M", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnComma->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x2c", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnComma->setText(QApplication::translate("WidgetKeyboard", ",", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnPeriod->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x2e", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnPeriod->setText(QApplication::translate("WidgetKeyboard", ".", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnBcwdSlash->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x2f", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnBcwdSlash->setText(QApplication::translate("WidgetKeyboard", "/", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnShiftRight->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x01000020", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnShiftRight->setText(QApplication::translate("WidgetKeyboard", "     Shift      ", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnCtrlLeft->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x01000021", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnCtrlLeft->setText(QApplication::translate("WidgetKeyboard", "    Ctrl     ", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnAltLeft->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x01000023", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnAltLeft->setText(QApplication::translate("WidgetKeyboard", "   Alt  ", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnSpace->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x20", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnSpace->setText(QString());
#ifndef QT_NO_TOOLTIP
        sliderOpacity->setToolTip(QApplication::translate("WidgetKeyboard", "Transparency", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_ACCESSIBILITY
        btnTab->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x01000001", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnTab->setText(QApplication::translate("WidgetKeyboard", "  Tab   ", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnQ->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x51", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnQ->setText(QApplication::translate("WidgetKeyboard", "Q", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnW->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x57", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnW->setText(QApplication::translate("WidgetKeyboard", "W", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnE->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x45", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnE->setText(QApplication::translate("WidgetKeyboard", "E", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnR->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x52", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnR->setText(QApplication::translate("WidgetKeyboard", "R", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnT->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x54", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnT->setText(QApplication::translate("WidgetKeyboard", "T", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnY->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x59", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnY->setText(QApplication::translate("WidgetKeyboard", "Y", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnU->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x55", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnU->setText(QApplication::translate("WidgetKeyboard", "U", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnI->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x49", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnI->setText(QApplication::translate("WidgetKeyboard", "I", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnO->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x4f", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnO->setText(QApplication::translate("WidgetKeyboard", "O", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnP->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x50", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnP->setText(QApplication::translate("WidgetKeyboard", "P", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnStartSquare->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x5b", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnStartSquare->setText(QApplication::translate("WidgetKeyboard", "[", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnCloseSquare->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x5d", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnCloseSquare->setText(QApplication::translate("WidgetKeyboard", "]", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_ACCESSIBILITY
        btnFwdSlash->setAccessibleName(QApplication::translate("WidgetKeyboard", "0x5c", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_ACCESSIBILITY
        btnFwdSlash->setText(QApplication::translate("WidgetKeyboard", "\\", 0, QApplication::UnicodeUTF8));

        Q_UNUSED(WidgetKeyboard);
    } // retranslateUi

};

namespace Ui {
    class WidgetKeyboard: public Ui_WidgetKeyboard {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGETKEYBOARD_H
